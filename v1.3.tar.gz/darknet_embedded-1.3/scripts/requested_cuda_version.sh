#!/usr/bin/env bash

export CUDA_VERSION="12.6"
export CUDA_VERSION_DASHED="${CUDA_VERSION//./-}"
